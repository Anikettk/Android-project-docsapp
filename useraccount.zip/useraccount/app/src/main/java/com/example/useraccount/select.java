package com.example.useraccount;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import static java.lang.Thread.sleep;

public class select extends AppCompatActivity {
    ImageView sel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

        ImageView sel = (ImageView) findViewById(R.id.select);

        Animation myanim = AnimationUtils.loadAnimation(this,R.anim.myanimation);

        select.startAnimation(myanim);

        Thread myThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    sleep(1000);
                    Intent i = new Intent(select.this,MainActivity.class);
                    startActivity(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });
        myThread.start();
    }

    private static void startAnimation(Animation myanim) {
    }


}
