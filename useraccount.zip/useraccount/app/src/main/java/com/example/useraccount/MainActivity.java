package com.example.useraccount;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class MainActivity<loginActivity, mainActivity> extends AppCompatActivity {
    EditText ed_email,ed_password;
    EditText txtEmail,txtPassword;
    String url = "https://docsapp2.000webhostapp.com/login.php";
    TextView tvregister;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed_email = findViewById(R.id.loginemail);
        ed_password = findViewById(R.id.loginpass);

        tvregister = findViewById(R.id.textView);


        tvregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,registerActivity.class);
                startActivity(i);
            }
        });

    }
    public void Login(View view) {
        if(ed_email.getText().toString().equals("")){
            Toast.makeText(this, "enter email id", Toast.LENGTH_SHORT).show();
        }
        else if(ed_password.getText().toString().equals("")){
            Toast.makeText(this, "enter password", Toast.LENGTH_SHORT).show();
        }
        else{
            final String email = ed_email.getText().toString();
            final String password = ed_password.getText().toString();

            StringRequest request = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {

                        @Override
                        public void onResponse(String response) {
                            if(response.equalsIgnoreCase("login successfully")) {
                                ed_email.setText("");
                                ed_password.setText("");
                                startActivity(new Intent(MainActivity.this, navigationActivity2.class));
                                Toast.makeText(MainActivity.this, "log in successfully", Toast.LENGTH_SHORT).show();


                            }
                            else{
                                Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();

                            }

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();

                }
            })
            {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String, String>();

                    params.put("email",email);
                    params.put("password",password);
                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            requestQueue.add(request);

        }

    }

}
