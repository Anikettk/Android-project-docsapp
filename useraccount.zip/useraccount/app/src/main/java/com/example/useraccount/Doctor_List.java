package com.example.useraccount;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Doctor_List extends AppCompatActivity {
    TextView name,name2,name3,name4,name5,name6;
    Button btn1,btn2,btn3,btn4,btn5,btn6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor__list);
        name = findViewById(R.id.name);
        name2 = findViewById(R.id.name2);
        name3 = findViewById(R.id.name3);
        name4 = findViewById(R.id.name4);
        name5 = findViewById(R.id.name5);
        name6 = findViewById(R.id.name6);
        btn1=findViewById(R.id.buttonProfile1);
        btn2=findViewById(R.id.buttonProfile2);
        btn3=findViewById(R.id.buttonProfile3);
        btn4=findViewById(R.id.buttonProfile4);
        btn5=findViewById(R.id.buttonProfile5);
        btn6=findViewById(R.id.buttonProfile6);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=name.getText().toString();
                Intent i = new Intent(Doctor_List.this,DoctorDetail.class);
                i.putExtra("data",data);
                startActivity(i);

            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=name2.getText().toString();
                Intent i = new Intent(Doctor_List.this,DoctorDetail.class);
                i.putExtra("data",data);
                startActivity(i);

            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=name3.getText().toString();
                Intent i = new Intent(Doctor_List.this,DoctorDetail.class);
                i.putExtra("data",data);
                startActivity(i);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=name4.getText().toString();
                Intent i = new Intent(Doctor_List.this,DoctorDetail.class);
                i.putExtra("data",data);
                startActivity(i);
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=name5.getText().toString();
                Intent i = new Intent(Doctor_List.this,DoctorDetail.class);
                i.putExtra("data",data);
                startActivity(i);
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data=name6.getText().toString();
                Intent i = new Intent(Doctor_List.this,DoctorDetail.class);
                i.putExtra("data",data);
                startActivity(i);
            }
        });


    }
}
