package com.example.useraccount;
        import android.app.DatePickerDialog;
        import android.app.TimePickerDialog;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.DatePicker;
        import android.widget.EditText;
        import android.widget.ImageButton;
        import android.widget.ImageView;
        import android.widget.TextView;
        import android.widget.TimePicker;
        import android.widget.Toast;

        import androidx.appcompat.app.AppCompatActivity;
        import androidx.fragment.app.DialogFragment;

        import com.google.android.material.textfield.TextInputLayout;

        import java.text.DateFormat;
        import java.util.Calendar;

public class DocDetails extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {
    ImageView docImage;
    TextView docDescription,docName,docFee,docQualfication;
    Button button;
    private TextInputLayout textdate,texttime;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_details);
        textdate = findViewById(R.id.til_date);
        texttime = findViewById(R.id.til_time);
        docDescription = findViewById(R.id.iddescription);
        docName = findViewById(R.id.idname);
        docName.setText(getIntent().getStringExtra("data"));
        docFee = findViewById(R.id.idPrice);
        docQualfication = findViewById(R.id.idqualification);
        docImage = findViewById(R.id.imageButton);
        button = findViewById(R.id.button2 );
        ImageButton time_button = findViewById(R.id.id_time);
        ImageButton cal_button = findViewById(R.id.id_calendar);
        time_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment timePicker = new TimePickerFragment();
                timePicker.show(getSupportFragmentManager(),"timePicker");
            }
        });
        cal_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(),"datePicker");
            }
        });

        Bundle mbundle = getIntent().getExtras();

        if(mbundle != null)
        {
            docDescription.setText(mbundle.getString("Description"));
            docImage.setImageResource(mbundle.getInt("Image"));
            docQualfication.setText(mbundle.getString("Qualification"));
            docName.setText(mbundle.getString("Name"));
            docFee.setText(mbundle.getString("Fee"));

        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!validateDate()| !validateTime()){
                    return;
                }
                Toast.makeText(DocDetails.this, "Appointment Booked Successfully", Toast.LENGTH_SHORT).show();

            }
        });


    }
    public boolean validateDate(){
        String date = textdate.getEditText().getText().toString().trim();

        if(date.isEmpty()){
            textdate.setError("Field can't be empty");
            return false;

        }
        else {
            textdate.setError(null);
            return true;
        }
    }

    public boolean validateTime(){
        String time = texttime.getEditText().getText().toString().trim();

        if(time.isEmpty()){
            texttime.setError("Field can't be empty");
            return false;

        }
        else {
            texttime.setError(null);
            return true;
        }
    }


    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR,year);
        c.set(Calendar.MONTH,month);
        c.set(Calendar.DATE,dayOfMonth);
        String currentDateString = DateFormat.getDateInstance().format(c.getTime());
        EditText txtdate = findViewById(R.id.txt_calendar);
        txtdate.setText(currentDateString);

    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        EditText txttime = findViewById(R.id.txt_time);
        txttime.setText(hourOfDay + ":" + minute);
    }
}
