package com.example.useraccount;

import android.content.Context;
import android.content.SharedPreferences;

public class UserPreference {
    SharedPreferences sharedPreferences;
    Context context;
    private String email;

    public void removeUserPreference()
    {
        sharedPreferences.edit().clear().commit();
    }


    public String getEmail() {
        sharedPreferences.getString("userdata","");
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
        sharedPreferences.edit().putString("userdata",email).commit();
    }

    public UserPreference(Context context){
        this.context=context;
        sharedPreferences = context.getSharedPreferences("userinfo",Context.MODE_PRIVATE);

    }
}
