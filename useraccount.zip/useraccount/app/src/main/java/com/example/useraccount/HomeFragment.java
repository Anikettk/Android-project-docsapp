package com.example.useraccount;

import android.app.Person;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {
    Button buttonProfile1,buttonProfile,buttonProfile3,buttonProfile4;
    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.home_fragment, container, false);
        buttonProfile1 = v.findViewById(R.id.buttonProfile1);
        buttonProfile1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),ConsultActivity.class);
                startActivity(i);


            }
        });

        buttonProfile=v.findViewById(R.id.buttonProfile);
        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),ConsultActivity.class);
                startActivity(i);

            }
        });

        buttonProfile3=v.findViewById(R.id.buttonProfile3);
        buttonProfile3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),ConsultActivity.class);
                startActivity(i);

            }
        });


        buttonProfile4=v.findViewById(R.id.buttonProfile4);
        buttonProfile4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(),Doctor_List.class);
                startActivity(i);
            }
        });

        return  v;
    }





}
