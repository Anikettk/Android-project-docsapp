package com.example.useraccount;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.GridLayout;
import android.widget.Toast;

public class Msg extends AppCompatActivity {
    GridLayout mainGrid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msg);

        mainGrid = (GridLayout)findViewById(R.id.mainGrid);
        setSingleEvent(mainGrid);
        //setToggleEvent(mainGrid);
    }

    private void setToggleEvent(GridLayout mainGrid) {
        for(int i=0; i<mainGrid.getChildCount(); i++){
            final CardView cardView =(CardView)mainGrid.getChildAt(i);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(cardView.getCardBackgroundColor().getDefaultColor()== -1){
                        cardView.setCardBackgroundColor(Color.parseColor("#666f78"));
                        Toast.makeText(Msg.this, "selected", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        cardView.setCardBackgroundColor(Color.parseColor("#E91E63"));
                        Toast.makeText(Msg.this, "unselected", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void setSingleEvent(GridLayout mainGrid){
        for(int i= 0;i<mainGrid.getChildCount();i++){
            CardView cardView =(CardView)mainGrid.getChildAt(i);
            final int finali =i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Msg.this,msg2.class);
                    startActivity(i);
                }
            });

        }
    }
}
