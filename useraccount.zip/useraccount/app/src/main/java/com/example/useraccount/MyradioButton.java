package com.example.useraccount;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.CompoundButton;

import androidx.appcompat.widget.AppCompatRadioButton;

public class MyradioButton extends AppCompatRadioButton {

    private OnCheckedChangeListener onCheckedChangeListener;

    public MyradioButton(Context context) {
        super(context);
    }

    public MyradioButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyradioButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        setOwnOncheckedListener();
        setButtonDrawable(null);
    }

    public void setOwnOnCheckedChangeListener(OnCheckedChangeListener onCheckedChangeListener){
        this.onCheckedChangeListener = onCheckedChangeListener;
    }

    private void setOwnOncheckedListener() {
        setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(onCheckedChangeListener != null){
                    onCheckedChangeListener.onCheckedChanged(buttonView, isChecked);
                }
            }
        });

    }
}
