package com.example.useraccount;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class msg2 extends AppCompatActivity {
    EditText txt_number,txt_message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msg2);

        txt_number=findViewById(R.id.txt_number);
        txt_message=findViewById(R.id.txt_message);
    }

    public void btn_send(View view) {
        int  permuissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if(permuissionCheck== PackageManager.PERMISSION_GRANTED){
            MyMessage();
        }
        else
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},0);
        }
    }

    private void MyMessage() {
        String pnumber = txt_number.getText().toString().trim();
        String message = txt_message.getText().toString().trim();

        if(!txt_number.getText().toString().equals("") || !txt_message.getText().toString().equals("")) {
            txt_number.setText(" ");
            txt_message.setText("");
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(pnumber, null, message, null, null);
            Toast.makeText(this, "send message", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "enter valid number or message", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case 0:
                if(grantResults.length>=0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    MyMessage();
                }
                else{
                    Toast.makeText(this, "you dont have a required permission", Toast.LENGTH_SHORT).show();
                }
        }
    }
}
